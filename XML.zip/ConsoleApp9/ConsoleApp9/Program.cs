﻿using System;

class MainClass
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Введіть рядок");
        string str = Console.ReadLine();
        Console.WriteLine("Введіть 1 символ");
        string symv1 = Console.ReadLine();
        Console.WriteLine("Введіть 2 символ");
        string symv2 = Console.ReadLine();

        string result = insertSymv(str, symv1, symv2);

        Console.WriteLine(result);
    }

    public static string insertSymv(string str, string symv1, string symv2)
    {
        int index = str.IndexOf(symv1);
        while (index != -1)
        {
            str = str.Insert(index, symv2);
            index = str.IndexOf(symv1, index + 2);
        }
        return str;
    }
}
