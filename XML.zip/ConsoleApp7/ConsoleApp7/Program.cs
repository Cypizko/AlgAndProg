﻿using System;

class Program
{
    static void Main(string[] args)
    {
        string str = Console.ReadLine();

        if (str.Contains(" "))
        {

            int lastSpaceIndex = str.LastIndexOf(" ");

            str = str.Remove(lastSpaceIndex + 1);

            Console.WriteLine(str);
        }
        else
        {
            Console.WriteLine("У рядку немає пробілів.");
        }
    }
}
