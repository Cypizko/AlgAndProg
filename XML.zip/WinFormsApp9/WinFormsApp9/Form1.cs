using System.Data;
using System.Windows.Forms;

namespace WinFormsApp9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e) //������� ������
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);

            }
            else
            {
                MessageBox.Show("�������� ������ ��� ��������.", "������.");
            }
        }

        private void button2_Click(object sender, EventArgs e) //�����������
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int n = dataGridView1.SelectedRows[0].Index;
                dataGridView1.Rows[n].Cells[0].Value = textBox1.Text;
                dataGridView1.Rows[n].Cells[1].Value = comboBox1.Text;
                dataGridView1.Rows[n].Cells[2].Value = textBox2.Text;
                dataGridView1.Rows[n].Cells[3].Value = textBox3.Text;
            }
            else
            {
                MessageBox.Show("�������� ������ ��� ��������������.", "������.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (dataGridView1.Rows.Count > 0)
            {
                dataGridView1.Rows.Clear(); 
            }

            try
            {
                if (File.Exists("C:\\Users\\userc\\source\\repos\\WinFormsApp9\\WinFormsApp9\\XmlF.xml"))
                {
                    DataSet ds = new DataSet();
                    ds.ReadXml("C:\\Users\\userc\\source\\repos\\WinFormsApp9\\WinFormsApp9\\XmlF.xml"); 

                    foreach (DataRow item in ds.Tables["Invoice"].Rows)
                    {
                        int n = dataGridView1.Rows.Add(); 
                        dataGridView1.Rows[n].Cells[0].Value = item["Name"];
                        dataGridView1.Rows[n].Cells[1].Value = item["Details"];       
                        dataGridView1.Rows[n].Cells[2].Value = item["Model"];      
                        dataGridView1.Rows[n].Cells[3].Value = item["Price"]; 
                    }
                }
                else
                {
                    MessageBox.Show("XML ���� �� ������.", "������.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("������ ��� �������� XML �����: " + ex.Message, "������.");
            }
        }

        private void button1_Click(object sender, EventArgs e) 
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("��������� ��� ����.", "������.");
            }
            else
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = textBox1.Text;
                dataGridView1.Rows[n].Cells[1].Value = comboBox1.Text;
                dataGridView1.Rows[n].Cells[2].Value = textBox2.Text;
                dataGridView1.Rows[n].Cells[3].Value = textBox3.Text;
            }
        }

        private void button4_Click(object sender, EventArgs e) 
        {
            try
            {
                DataSet ds = new DataSet(); 
                DataTable dt = new DataTable(); 
                dt.TableName = "Invoice";
                dt.Columns.Add("Name"); 
                dt.Columns.Add("Details");
                dt.Columns.Add("Model");
                dt.Columns.Add("Price");
                ds.Tables.Add(dt); 

                foreach (DataGridViewRow r in dataGridView1.Rows) 

                {
                    DataRow row = ds.Tables["Invoice"].NewRow(); 

                    row["Name"] = r.Cells[0].Value; 

                    row["Details"] = r.Cells[1].Value; 
                    row["Model"] = r.Cells[2].Value;
                    row["Price"] = r.Cells[3].Value;  
                    ds.Tables["Invoice"].Rows.Add(row); 
                }
                ds.WriteXml("C:\\Users\\userc\\source\\repos\\WinFormsApp9\\WinFormsApp9\\XmlF.xml");
                MessageBox.Show("XML ���� ������� ��������.", "���������.");
            }
            catch
            {
                MessageBox.Show("���������� ��������� �ML.", "������.");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                dataGridView1.Rows.Clear();
            }
            else
            {
                MessageBox.Show("������� �����.", "������.");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) 
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            comboBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
        }
    }
}