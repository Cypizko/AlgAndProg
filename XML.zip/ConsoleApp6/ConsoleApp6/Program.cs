﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Введіть рядок:");
        string str = Console.ReadLine();

        Console.WriteLine("Введіть символ, яким потрібно замінити всі інші символи:");
        char symv = Console.ReadKey().KeyChar;

        string newStr = new string(symv, str.Length);

        Console.WriteLine($"\nЗамінений рядок: {newStr}");
    }
}
